"""Tests for carbonyl_agent.browser module."""
import os
from unittest.mock import MagicMock, patch

import pytest

from carbonyl_agent.browser import (
    _DOCKER_FALLBACK_ENV,
    ANTI_BOT_FLAGS,
    ANTI_FEDCM_FLAGS,
    ANTI_ONETAP_FLAGS,
    BASE_CHROMIUM_FLAGS,
    DEFAULT_HEADLESS_FLAGS,
    CarbonylBrowser,
    _is_text_char,
    _local_binary,
)


class TestDockerFallbackGate:
    """US-008: Docker fallback requires CARBONYL_ALLOW_DOCKER=1."""

    @patch("carbonyl_agent.browser._local_binary", return_value=None)
    def test_raises_without_env(self, mock_binary):
        """Docker fallback blocked when env var not set."""
        env = {k: v for k, v in os.environ.items() if k != _DOCKER_FALLBACK_ENV}
        with patch.dict(os.environ, env, clear=True):
            b = CarbonylBrowser()
            with pytest.raises(RuntimeError, match="CARBONYL_ALLOW_DOCKER"):
                b.open("https://example.com")

    @patch("carbonyl_agent.browser._local_binary", return_value=None)
    def test_raises_when_env_not_1(self, mock_binary):
        """Docker fallback blocked when env var is set but not '1'."""
        with patch.dict(os.environ, {_DOCKER_FALLBACK_ENV: "0"}):
            b = CarbonylBrowser()
            with pytest.raises(RuntimeError, match="CARBONYL_ALLOW_DOCKER"):
                b.open("https://example.com")


class TestTextFiltering:
    """Basic tests for text extraction utilities."""

    def test_is_text_char_letter(self):
        assert _is_text_char("A") is True

    def test_is_text_char_block(self):
        assert _is_text_char("\u2580") is False  # block element

    def test_is_text_char_space(self):
        assert _is_text_char(" ") is True


class TestLocalBinary:
    """Test binary discovery returns None or a valid path."""

    def test_returns_none_or_path(self):
        result = _local_binary()
        if result is not None:
            assert result.is_file()


class TestFlagGroups:
    """Flag groups are composable and can be selected by agents per scenario."""

    def test_default_is_base_plus_anti_bot(self):
        assert DEFAULT_HEADLESS_FLAGS == BASE_CHROMIUM_FLAGS + ANTI_BOT_FLAGS

    def test_onetap_alias_equals_fedcm(self):
        assert ANTI_ONETAP_FLAGS == ANTI_FEDCM_FLAGS

    def test_fedcm_flag_content(self):
        assert any("FedCm" in f for f in ANTI_FEDCM_FLAGS)

    def test_default_flags_used_when_none_specified(self):
        b = CarbonylBrowser()
        assert b._flags == list(DEFAULT_HEADLESS_FLAGS)

    def test_extra_flags_appended(self):
        extra = ["--disable-features=FedCm"]
        b = CarbonylBrowser(extra_flags=extra)
        assert b._flags == list(DEFAULT_HEADLESS_FLAGS) + extra

    def test_extra_flags_anti_fedcm_group(self):
        b = CarbonylBrowser(extra_flags=ANTI_FEDCM_FLAGS)
        assert b._flags[-len(ANTI_FEDCM_FLAGS):] == ANTI_FEDCM_FLAGS

    def test_base_flags_override_replaces_default(self):
        custom = ["--foo", "--bar"]
        b = CarbonylBrowser(base_flags=custom)
        assert b._flags == custom

    def test_base_and_extra_compose(self):
        base = ["--foo"]
        extra = ["--bar"]
        b = CarbonylBrowser(base_flags=base, extra_flags=extra)
        assert b._flags == ["--foo", "--bar"]


class TestViewport:
    """Consumer-controlled CSS viewport (carbonyl issue #37 fix)."""

    def test_default_is_none(self):
        b = CarbonylBrowser()
        assert b._viewport is None

    def test_accepts_tuple(self):
        b = CarbonylBrowser(viewport=(1280, 800))
        assert b._viewport == (1280, 800)


class TestInputBackend:
    """input_backend kwarg routes send/click/etc through the right path (#36)."""

    def test_default_is_pty(self):
        b = CarbonylBrowser()
        assert b.input_backend == "pty"

    def test_accepts_uinput(self):
        b = CarbonylBrowser(input_backend="uinput")
        assert b.input_backend == "uinput"

    def test_rejects_unknown_backend(self):
        with pytest.raises(ValueError, match="input_backend"):
            CarbonylBrowser(input_backend="bogus")

    def test_uinput_routes_send_through_emitter(self):
        b = CarbonylBrowser(input_backend="uinput")
        mock_emitter = MagicMock()
        b._uinput_emitter = mock_emitter
        # _ensure_uinput would normally lazy-create; we pre-set it
        b.send("hello")
        mock_emitter.type_text.assert_called_once_with("hello")

    def test_uinput_routes_send_key_through_emitter(self):
        b = CarbonylBrowser(input_backend="uinput")
        mock_emitter = MagicMock()
        b._uinput_emitter = mock_emitter
        b.send_key("enter")
        mock_emitter.press_key.assert_called_once_with("enter")

    def test_uinput_routes_click_through_emitter(self):
        b = CarbonylBrowser(input_backend="uinput", viewport=(1280, 800))
        mock_emitter = MagicMock()
        b._uinput_emitter = mock_emitter
        # cell (320, 105) → CSS pixel (640, 420)
        b.click(320, 105)
        mock_emitter.click.assert_called_once_with(640, 420)

    def test_uinput_routes_mouse_move_through_emitter(self):
        b = CarbonylBrowser(input_backend="uinput", viewport=(1280, 800))
        mock_emitter = MagicMock()
        b._uinput_emitter = mock_emitter
        b.mouse_move(100, 50)
        mock_emitter.move_mouse.assert_called_once_with(200, 200)

    def test_close_destroys_emitter(self):
        b = CarbonylBrowser(input_backend="uinput")
        mock_emitter = MagicMock()
        b._uinput_emitter = mock_emitter
        b.close()
        mock_emitter.close.assert_called_once()
        assert b._uinput_emitter is None

    def test_pty_backend_does_not_create_emitter(self):
        b = CarbonylBrowser(input_backend="pty")
        # Default backend should leave the emitter slot empty until any uinput
        # call is made (which there won't be, in pty mode).
        assert b._uinput_emitter is None


class TestPersonaGracefulShutdown:
    """Issue #49: persona= mode must use SIGTERM-then-SIGKILL like session= so
    Chromium can flush cookies/localStorage to disk before exit.
    """

    @patch("os.killpg")
    @patch("os.getpgid", return_value=12345)
    def test_persona_triggers_sigterm_path(self, _mock_getpgid, mock_killpg, tmp_path):
        import signal as _signal
        b = CarbonylBrowser(persona="alpha", profiles_dir=str(tmp_path))
        # Fake an alive child that exits quickly so the wait loop doesn't drag
        child = MagicMock()
        # First isalive() check enters the conditional, subsequent checks bail.
        child.isalive.side_effect = [True, False]
        child.pid = 99
        b._child = child
        b.close(graceful_timeout=0.1)
        # Both SIGTERM and SIGKILL should fire (SIGKILL is best-effort cleanup)
        signals_sent = [call.args[1] for call in mock_killpg.call_args_list]
        assert _signal.SIGTERM in signals_sent

    @patch("os.killpg")
    @patch("os.getpgid", return_value=12345)
    def test_no_persona_no_session_skips_sigterm(self, _mock_getpgid, mock_killpg):
        import signal as _signal
        b = CarbonylBrowser()  # neither persona nor session
        child = MagicMock()
        child.isalive.side_effect = [True, False]
        child.pid = 99
        b._child = child
        b.close(graceful_timeout=5.0)
        signals_sent = [call.args[1] for call in mock_killpg.call_args_list]
        assert _signal.SIGTERM not in signals_sent
        # SIGKILL still fires as the unconditional force-kill path
        assert _signal.SIGKILL in signals_sent

    @patch("os.killpg")
    @patch("os.getpgid", return_value=12345)
    def test_persona_with_zero_timeout_skips_sigterm(
        self, _mock_getpgid, mock_killpg, tmp_path
    ):
        import signal as _signal
        b = CarbonylBrowser(persona="alpha", profiles_dir=str(tmp_path))
        child = MagicMock()
        child.isalive.side_effect = [True, False]
        child.pid = 99
        b._child = child
        b.close(graceful_timeout=0)
        signals_sent = [call.args[1] for call in mock_killpg.call_args_list]
        assert _signal.SIGTERM not in signals_sent


class TestWaitForRenderSettle:
    """Issue #48: deterministic readiness probe so visual-capture tests don't
    rely on wall-clock drain() heuristics."""

    def _make_browser_with_text_sequence(self, sequence):
        """Build a browser whose drain() is a no-op and whose page_text() walks
        a pre-canned sequence of strings (last value sticks once exhausted)."""
        b = CarbonylBrowser()
        idx = {"i": 0}

        def _drain(_seconds):
            idx["i"] = min(idx["i"] + 1, len(sequence) - 1)

        def _text():
            return sequence[idx["i"]]

        b.drain = _drain  # type: ignore[method-assign]
        b.page_text = _text  # type: ignore[method-assign]
        return b

    def test_returns_true_when_buffer_settles(self):
        b = self._make_browser_with_text_sequence(["a", "ab", "abc", "abc", "abc", "abc"])
        assert b.wait_for_render_settle(timeout=2.0, idle_ms=50, poll_ms=10) is True

    def test_returns_false_when_buffer_never_settles(self):
        # Each drain() advances the index; supply a sequence so long the index
        # never catches up to a duplicate within the timeout window.
        b = CarbonylBrowser()
        counter = {"i": 0}

        def _drain(_s):
            counter["i"] += 1

        def _text():
            return f"frame-{counter['i']}"

        b.drain = _drain  # type: ignore[method-assign]
        b.page_text = _text  # type: ignore[method-assign]
        assert b.wait_for_render_settle(timeout=0.3, idle_ms=100, poll_ms=10) is False

    def test_validates_arguments(self):
        b = CarbonylBrowser()
        with pytest.raises(ValueError):
            b.wait_for_render_settle(timeout=0)
        with pytest.raises(ValueError):
            b.wait_for_render_settle(idle_ms=0)
        with pytest.raises(ValueError):
            b.wait_for_render_settle(poll_ms=0)


class TestContextManager:
    """Issue #24: __enter__/__exit__ so resources are cleaned up on
    exception, not just on explicit close()."""

    def test_returns_self_on_enter(self):
        b = CarbonylBrowser()
        with b as ctx:
            assert ctx is b

    def test_close_called_on_exit(self):
        b = CarbonylBrowser()
        b.close = MagicMock()  # type: ignore[method-assign]
        with b:
            pass
        b.close.assert_called_once()

    def test_close_called_on_exception(self):
        b = CarbonylBrowser()
        b.close = MagicMock()  # type: ignore[method-assign]
        with pytest.raises(RuntimeError, match="boom"):
            with b:
                raise RuntimeError("boom")
        b.close.assert_called_once()
